//https://jsonmock.hackerrank.com/api/movies/search/?Title=maze

const express = require('express');
const https = require('https');
const http = require('http');
const app = express();
var rp = require('request-promise');
const server = http.createServer(app);
const async = require('async');
app.set('port', 3000);

server.listen(3000, function() {});

app.get('/', (req, sres) => {
  var substr = 'Spiderman';
  var options = {
    uri: 'https://jsonmock.hackerrank.com/api/movies/search/?Title=' + substr,
    method: 'get',
    json: true // Automatically parses the JSON string in the response
  };
  var titleAry = [];
  rp(options).then(function(parsedBody) {
    var totalPage = parsedBody.total_pages;
    var urls = [];
    for (var i = 1; i < totalPage + 1; i++) {
      urls.unshift('https://jsonmock.hackerrank.com/api/movies/search/?Title=' + substr + '&page=' + i);
    }

    async.map(urls, function(url, callback) {
      request(url, function(error, response, html) {
        // Some processing is happening here before the callback is invoked
        callback(error, html);
      });
    }, function(err, results) {
      // the result jsons should be in the results[]
      console.log(results);
      sres.json(results);
    });

  }).catch(function(err) {
    // POST failed...
  });
})
