Run
```
  npm install

  ...

  node index.js

  ...

  Get localhost:3000
```
